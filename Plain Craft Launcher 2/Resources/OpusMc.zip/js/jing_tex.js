'use strict';
// 鲸鲸 (the AI companion, companion.js): jing.webp, 2048 x 2048 - the sphere's front | back on top (1024 x 1024 each,
// seen straight on, the back mirrored) and the parts below. Made with gpt-image-2.5-sunburst at 2880 x 2880 from the
// user's character (2026-11-01; the first pixel-art version was too blurry for the user)
window.JING_TEX = { src: 'js/jing.webp', size: 2048, cell: 1024, parts: {"ear": [120, 1032, 784, 496], "tail": [1166, 1032, 740, 496], "crown": [66, 1544, 891, 496], "ahoge": [1078, 1544, 404, 496]} };
